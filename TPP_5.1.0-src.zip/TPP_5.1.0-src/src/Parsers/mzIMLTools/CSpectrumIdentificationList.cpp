/*
Copyright 2017, Michael R. Hoopmann, Institute for Systems Biology
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include "CSpectrumIdentificationList.h"

CSpectrumIdentificationList::CSpectrumIdentificationList(){
  id = "null";
  name.clear();
  numSequencesSearched=0;

  CSpectrumIdentificationResult sir;
  spectrumIdentificationResult = new vector<CSpectrumIdentificationResult>;
  spectrumIdentificationResult->push_back(sir);

  cvParam = new vector<sCvParam>;
  userParam = new vector<sUserParam>;
}

CSpectrumIdentificationList::CSpectrumIdentificationList(const CSpectrumIdentificationList& s){
  id=s.id;
  name=s.name;
  numSequencesSearched=s.numSequencesSearched;

  fragmentationTable=s.fragmentationTable;

  size_t i;
  spectrumIdentificationResult = new vector<CSpectrumIdentificationResult>;
  cvParam = new vector<sCvParam>;
  userParam = new vector<sUserParam>;
  for (i = 0; i<s.spectrumIdentificationResult->size(); i++) spectrumIdentificationResult->push_back(s.spectrumIdentificationResult->at(i));
  for (i = 0; i<s.cvParam->size(); i++) cvParam->push_back(s.cvParam->at(i));
  for (i = 0; i<s.userParam->size(); i++) userParam->push_back(s.userParam->at(i));
}

CSpectrumIdentificationList::~CSpectrumIdentificationList(){
  delete spectrumIdentificationResult;
  delete cvParam;
  delete userParam;
}

CSpectrumIdentificationList& CSpectrumIdentificationList::operator=(const CSpectrumIdentificationList& s){
  if (this != &s){
    id = s.id;
    name = s.name;
    numSequencesSearched = s.numSequencesSearched;

    fragmentationTable = s.fragmentationTable;

    size_t i;
    delete spectrumIdentificationResult;
    delete cvParam;
    delete userParam;
    spectrumIdentificationResult = new vector<CSpectrumIdentificationResult>;
    cvParam = new vector<sCvParam>;
    userParam = new vector<sUserParam>;
    for (i = 0; i<s.spectrumIdentificationResult->size(); i++) spectrumIdentificationResult->push_back(s.spectrumIdentificationResult->at(i));
    for (i = 0; i<s.cvParam->size(); i++) cvParam->push_back(s.cvParam->at(i));
    for (i = 0; i<s.userParam->size(); i++) userParam->push_back(s.userParam->at(i));
  }
  return *this;
}

//iterate through sequences to see if we have it already
//if so, return the existing id, else add this new one
CSpectrumIdentificationResult* CSpectrumIdentificationList::addSpectrumIdentificationResult(string specID, string& sdRef) {
  //get rid of any null placeholders
  if (spectrumIdentificationResult->at(0).id.compare("null") == 0) spectrumIdentificationResult->clear();

  //add new result
  CSpectrumIdentificationResult sir;
  char dbid[32];
  sprintf(dbid, "%s_%d", &sdRef[0], spectrumIdentificationResult->size());
  sir.id = dbid;
  sir.spectrumID=specID;
  sir.spectraDataRef=sdRef;
  spectrumIdentificationResult->push_back(sir);

  return &spectrumIdentificationResult->back();
}

CSpectrumIdentificationResult* CSpectrumIdentificationList::addSpectrumIdentificationResult(CSpectrumIdentificationResult& c) {
  //get rid of any null placeholders
  if (spectrumIdentificationResult->at(0).id.compare("null") == 0) spectrumIdentificationResult->clear();

  //add new result
  spectrumIdentificationResult->push_back(c);
  return &spectrumIdentificationResult->back();
}

void CSpectrumIdentificationList::writeOut(FILE* f, int tabs){
  int i;
  size_t j;
  for (i = 0; i<tabs; i++) fprintf(f, " ");
  fprintf(f, "<SpectrumIdentificationList id=\"%s\"",&id[0]);
  if(numSequencesSearched>0) fprintf(f," numSequencesSearched=\"%d\"",numSequencesSearched);
  fprintf(f, ">\n");
  if(tabs>-1) fragmentationTable.writeOut(f,tabs+1);
  else fragmentationTable.writeOut(f);
  for (j = 0; j < spectrumIdentificationResult->size(); j++){
    if (tabs>-1) spectrumIdentificationResult->at(j).writeOut(f, tabs + 1);
    else spectrumIdentificationResult->at(j).writeOut(f);
  }
  for (j = 0; j<cvParam->size(); j++){
    if (tabs>-1) cvParam->at(j).writeOut(f, tabs + 1);
    else cvParam->at(j).writeOut(f);
  }
  for (j = 0; j<userParam->size(); j++){
    if (tabs>-1) userParam->at(j).writeOut(f, tabs + 1);
    else userParam->at(j).writeOut(f);
  }
  for (i = 0; i<tabs; i++) fprintf(f, " ");
  fprintf(f, "</SpectrumIdentificationList>\n");
}
