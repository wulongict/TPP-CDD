#ifndef _CPEPXMLANALYSIS_H
#define _CPEPXMLANALYSIS_H

#include "PepXMLStructs.h"
#include <string>
#include <vector>

using namespace std;

class CPepXMLAnalysis {
public:

  CPepXMLAnalysis();
  //CPepXMLAnalysis(const CPepXMLAnalysis& p);
  //~CPepXMLAnalysis();

  //CPepXMLAnalysis& operator=(const CPepXMLAnalysis& p);

  void clear();
  
  string analysis; //name of the analysis
  string version;

};

#endif
