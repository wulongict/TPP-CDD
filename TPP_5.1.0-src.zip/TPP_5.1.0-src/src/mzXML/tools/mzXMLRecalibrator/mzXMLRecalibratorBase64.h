#ifndef _RAMPBASE64_H
#define _RAMPBASE64_H

unsigned long b64_decode_mio (char *dest, char *src);
#endif /* BASE64_H */
