/*
Copyright 2017, Michael R. Hoopmann, Institute for Systems Biology
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include "Parsers/mzIMLTools/mzIMLTools.h"
#include "PepXMLParser3.h"
#include "ProtXMLParser2.h"
#include <cstdio>
#include <iostream>

using namespace std;

bool convertPep(CMzIdentML& m, char* in);
bool convertProt(CMzIdentML& m, char* in);
bool summary(char* in);

int main(int argc, char* argv[]){

  if (argc != 2){
    cout << "MzIMLDemo v0.3.2 (Mar 27 2017), copyright Mike Hoopmann, Institute for Systems Biology." << endl;
    cout << "This program demos use of mzIMLTools library." << endl;
    cout << "When given a pepXML or protXML file, it will convert it to mzID." << endl;
    cout << "When given an mzID file, it will output a summary." << endl;
    cout << "USAGE: MzIMLDemo <pepXML|protXML|mzid>" << endl;
    return 1;
  }

  CMzIdentML m;

  //Make outfile
  string outFile = argv[1];
  size_t pos;
  pos = outFile.find(".pep.xml");
  if (pos != string::npos){
    outFile.replace(pos, 8, ".mzid");
    if(!convertPep(m, argv[1])){
      return -1;
    }
    cout << "1 Exporting: " << outFile << endl;
    m.writeFile(&outFile[0]);
    cout << "1 Done" << endl;
    return 0;
  }

  pos = outFile.find(".prot.xml");
  if (pos != string::npos){
    outFile.replace(pos, 9, ".mzid");
    if(!convertProt(m, argv[1])){
      return -2;
    }
    cout << "2 Exporting: " << outFile << endl;
    m.writeFile(&outFile[0]);
    cout << "2 Done" << endl;
    return 0;
  }

  pos = outFile.find(".mzid");
  if (pos == string::npos){
    cout << "Error: input file must contain the .pep.xml or .prot.xml or .mzid extension (case sensitive)." << endl;
    return -1;
  } else {
    cout << "3 Summary: " << endl;
    summary(argv[1]);
  }

  return 0;
}

bool convertPep(CMzIdentML& m, char* in){

  cout << "Reading: " << in << endl;

  PepXMLParser3 p;
  if(!p.readFile(in)){
    cout << "Failed to read pepXML: " << in << endl;
    return false;
  }

  cout << p.size() << " psms read." << endl;

  //Iterate through all psms
  size_t i,j;
  string analysisSoftware_ref;
  string cStr;
  string dbSequence_ref;
  string peptide_ref;
  string protein;
  string proteinDesc;
  string spectraData_ref;
  string searchDatabase_ref;
  //string spectrumIdentificationList_ref;
  CModification mod;
  CSpectrumIdentification* si;
  CSpectrumIdentificationItem* sii;
  CSpectrumIdentificationList* sil;
  CSpectrumIdentificationProtocol* sip;
  CSpectrumIdentificationResult* sir;
  vector<CModification> mods;
  vector<sPeptideEvidenceRef> pepRef;
  PepXMLMod pMod;
  CPepXMLSearch pSearch;
  CPepXMLAnalysis pAnalysis;
  PepXMLSearchMod pSearchMod;
  char str[256];

  //populate software used from the pepxml
  for (i = 0; i < p.getAnalysisCount(); i++){
    pAnalysis = p.getAnalysis(i);
    analysisSoftware_ref = m.addAnalysisSoftware(pAnalysis.analysis, pAnalysis.version);
  }

  for (i = 0; i < p.size(); i++){
    //skip scan if there are no psms
    if (p[i].psms->size()==0) continue;

    //Add/obtain the reference id for the psm data file.
    spectraData_ref = m.addSpectraData(p.getFile((int)i));
    searchDatabase_ref = m.addDatabase(p.getProteinDB(i,0));

    //Get the SIL_ref from the combo of datafile and db searched; 
    //in the future, this needs to include search algorithm; pepXML should have its own data structure
    si = m.addSpectrumIdentification(spectraData_ref,searchDatabase_ref);
    sil = m.getSpectrumIdentificationList(si->spectrumIdentificationListRef);
    sip = m.getSpectrumIdentificationProtocol(si->spectrumIdentificationProtocolRef);

    sip->threshold.cvParam->at(0).accession = "MS:1001494";
    sip->threshold.cvParam->at(0).cvRef = "PSI-MS";
    sip->threshold.cvParam->at(0).name = "no threshold";

    //populate analysis software & protocol information if it is new
    if (sip->analysisSoftwareRef.compare("null")==0){
      pSearch = p.getSearchParams(i);

      //manually setting search type
      sip->searchType.cvParam.accession = "MS:1001083";
      sip->searchType.cvParam.cvRef = "PSI-MS";
      sip->searchType.cvParam.name = "ms-ms search";

      analysisSoftware_ref=m.addAnalysisSoftware(pSearch.alg,pSearch.version);
      sip->analysisSoftwareRef = analysisSoftware_ref;
      
      for (j = 0; j<pSearch.mods->size(); j++){
        pSearchMod = pSearch.mods->at(j);
        cStr.clear();
        cStr += pSearchMod.aa;
        sip->modificationParams.addSearchModification(pSearchMod.fixed, pSearchMod.mass, cStr, pSearchMod.proteinTerm);
      }
      m.consolidateSpectrumIdentificationProtocol();
      sip = m.getSpectrumIdentificationProtocol(si->spectrumIdentificationProtocolRef);
    }

    //Create spectrum
    //sprintf(str, "scan=%d", p[i].scanNumber);
    sir = sil->addSpectrumIdentificationResult(p[i].nativeID,spectraData_ref);

    //for each PSM
    CPepXMLPSM psm = p.getPSM(i);

    //Get peptide sequence and modifications
    mods.clear();
    for (j = 0; j < p.getPeptideModCount(i); j++){
      pMod=p.getPeptideMod(i,j);
      mod.location=(int)pMod.aa+1;
      mod.monoisotopicMassDelta=pMod.massDiff;
      if(mod.location>0) mod.residues = p.getPeptide(i)[pMod.aa];
      else mod.residues.clear();
      mod.cvParam->at(0) = sip->modificationParams.getModificationCvParam(mod.monoisotopicMassDelta, mod.residues,mod.location==0);
      mods.push_back(mod);
    }
    string peptide_ref = m.addPeptide(p.getPeptide(i), mods);
    
    //Add all proteins mapped by this peptide
    pepRef.clear();
    j=0;
    proteinDesc = p.getProteinDesc(i,j);
    protein=p.getProtein(i,j++);
    while (protein.size()>0){
      dbSequence_ref = m.addDBSequence(protein,searchDatabase_ref,proteinDesc);
      pepRef.push_back(m.addPeptideEvidence(dbSequence_ref, peptide_ref));
      protein = p.getProtein(i, j++);
    }

    //Add PSM
    sii = sir->addSpectrumIdentificationItem(p[i].charge, (p[i].precursorNeutMass+1.007276466*p[i].charge)/p[i].charge, 1, pepRef, true, peptide_ref);
    sii->calculatedMassToCharge = (psm.calcPSMNeutMass + 1.007276466*p[i].charge) / p[i].charge;
    sir->addCvParam("MS:1000894", (double)p[i].rTimeSec);

    //add scores
    for (j = 0; j<p[i].psms->at(0).psmScores->size(); j++){
      sii->addPSMValue(pSearch.alg, p.getScoreLabel(p[i].psms->at(0).psmScores->at(j).index), p[i].psms->at(0).psmScores->at(j).value);
    }
    //add probabilities
    if (p.hasPepProphet()){
      sprintf(str, "%.6lf", p[i].psms->at(0).probability);
      sii->addPSMValue("PeptideProphet", "Probability", str);
    }
    if (p.hasIProphet()){
      sprintf(str, "%.6lf", p[i].psms->at(0).iProphetProbability);
      sii->addPSMValue("iProphet", "Probability", str);
    }
  }

  return true;
}

bool convertProt(CMzIdentML& m, char* in){

  cout << "Reading: " << in << endl;

  ProtXMLParser2 p;
  if(!p.readFile(in)){
    cout << "Failed to read protXML: " << in << endl;
    return false;
  }
  for (size_t f = 0; f < p.getSourceFileCount(); f++){
    if(!convertPep(m, &p.getSourceFile(f)[0])) return false;
  }

  m.dataCollection.analysisData.buildPeptideEvidenceTable();
  cout << p.size() << " proteins read." << endl;

  //Iterate through all psms
  bool bMass;
  char aa;
  size_t i, j, k, n,z,y,x;
  string analysisSoftware_ref;
  string cStr;
  string sMass;
  string dbSequence_ref;
  string peptide_ref;
  string peptideEvidence_ref;
  string proteinGroup;
  string spectraData_ref;
  string searchDatabase_ref;
  //string spectrumIdentificationList_ref;
  CDBSequence dbs;
  CModification mod;
  CPeptide pep;
  CPeptideEvidence* pe;
  CPeptideHypothesis* ph;
  CProteinAmbiguityGroup* pag;
  CProteinDetection pd;
  CProteinDetectionHypothesis* pdh;
  CProteinDetectionList* pdl;
  CSpectrumIdentificationList* sil;
  CSpectrumIdentificationItem* sii;
  vector<CModification> mods;
  vector<sPeptideEvidenceRef> pepRef;
  PepXMLMod pMod;
  CPepXMLSearch pSearch;
  PepXMLSearchMod pSearchMod;
  vector<string> vSII;
  string strstrstr;
  sCvParam cv;
  char str[256];

  //Add protein inference software
  analysisSoftware_ref = m.addAnalysisSoftware(p.getAlgorithm(), p.getVersion());

  //ProteinDetectionProtocol
  pd.proteinDetectionProtocolRef = m.analysisProtocolCollection.addProteinDetectionProtocol(analysisSoftware_ref);
  m.analysisProtocolCollection.proteinDetectionProtocol.threshold.cvParam->at(0).accession = "MS:1001494";
  m.analysisProtocolCollection.proteinDetectionProtocol.threshold.cvParam->at(0).cvRef = "PSI-MS";
  m.analysisProtocolCollection.proteinDetectionProtocol.threshold.cvParam->at(0).name = "no threshold";

  //ProteinDetectionList
  pd.proteinDetectionListRef = m.dataCollection.analysisData.proteinDetectionList.id = "PDL0";
  cv.cvRef = "PSI-MS";
  cv.accession = "MS:1002404";
  cv.name = "count of identified proteins";
  sprintf(str, "%d", p.size());
  cv.value = str;
  m.dataCollection.analysisData.proteinDetectionList.cvParam->push_back(cv);
  

  //ProteinDetection
  pd.id = "PD0";
  for (i = 0; i<m.dataCollection.analysisData.spectrumIdentificationList->size(); i++){
    pd.addInputSpectrumIdentification(m.dataCollection.analysisData.spectrumIdentificationList->at(i).id);
  }
  m.analysisCollection.addProteinDetection(pd);

  for (i = 0; i < p.size(); i++){
    //cout << "Protein Group " << i << " of " << p.size() << endl;
    pag = m.addProteinAmbiguityGroup();

    //add scores
    pag->addParamValue(p.getAlgorithm(), "probability", p[i].probability);
    pag->addParamValue(p.getAlgorithm(), "protein_group_passes_threshold", "true");

    //iterate over all proteins in the group
    for (j = 0; j < p[i].size(); j++){
      //cout << "\tProtein " << j << " of " << p[i].size() << " is " << p[i][j].proteinName << endl;
      dbs = m.getDBSequence(p[i][j].proteinName);
      //cout << "\tGot DBS: " << dbs.id << "\t" << dbs.accession << endl;
      pdh = pag->addProteinDetectionHypothesis(pag->id,dbs.id);
      //cout << "\tAdded PDH: " << pdh->id << endl;

      //protein scores
      pdh->addParamValue(p.getAlgorithm(), "probability", p[i][j].probability);
      pdh->addParamValue(p.getAlgorithm(), "coverage", p[i][j].percentCoverage);
      if (j == 0) pdh->addParamValue(p.getAlgorithm(), "leading_protein", "");
      if (j == 0) pdh->addParamValue(p.getAlgorithm(), "group_representative", "");
      if (j>0 && p[i][j].probability == p[i][0].probability) pdh->addParamValue(p.getAlgorithm(), "leading_protein", "");
      else pdh->addParamValue(p.getAlgorithm(), "non_leading_protein", "");

      //iterate over all peptides
      for (k = 0; k < p[i][j].size(); k++){
        pep.peptideSequence.text = p[i][j][k].peptideSequence;
        
        //identify unique combos of mods on the peptides
        for (y = 0; y < p[i][j][k].size(); y++){
          pep.modification->clear();
          cStr=p[i][j][k][y].modificationInfo.modifiedPeptide;
          z=0;
          bMass=false;
          for (n = 0; n < cStr.size(); n++){
            if (cStr[n]=='n') {
              z++;
              mod.location=0;
            } else if (cStr[n] == '['){
              z++;
              sMass.clear();
              aa = cStr[n-1];
              bMass=true;
            } else if (cStr[n] == ']'){
              z++;
              mod.monoisotopicMassDelta = atoi(&sMass[0]);
              switch (aa){
              case 'n': mod.monoisotopicMassDelta-=1; break;
              case 'C': mod.monoisotopicMassDelta-=103; break;
              case 'K': mod.monoisotopicMassDelta-=128; break;
              case 'M': mod.monoisotopicMassDelta-=131; break;
              default: break;
              }
              if (mod.location==-1) mod.location=n-z+1;
              pep.modification->push_back(mod);
              mod.location=-1;
              bMass=false;
            } else {
              if (bMass) {
                sMass += cStr[n];
                z++;
              }
            }
          }

          //cout << "\t\tPeptide is: " << pep.peptideSequence.text << " with " << pep.modification->size() << " mods." << endl;

          //find peptide sequence from list in mzid
          peptideEvidence_ref = m.sequenceCollection.getPeptideEvidenceFromPeptideAndProtein(pep,dbs.id);
          if (peptideEvidence_ref.size()<1){
            cout << "Warning, no peptide evidence found for (mod): " << pep.peptideSequence.text << " " << " from " << p[i][j].proteinName << endl;
            exit(1);
          }
          ph = pdh->addPeptideHypothesis(peptideEvidence_ref);

          m.dataCollection.analysisData.getSpectrumIdentificationItems(peptideEvidence_ref, p[i][j][k][y].charge, vSII);
          for (n = 0; n < vSII.size(); n++){
            //strstrstr=vSII.at(n);
            ph->addSpectrumIdentificationItemRef(vSII.at(n));
          }

        }

        //for case where there are no indistinguishable peptides
        if (p[i][j][k].size() == 0){
          pep.modification->clear();
          cStr = p[i][j][k].modificationInfo.modifiedPeptide;
          z = 0;
          bMass = false;
          for (n = 0; n < cStr.size(); n++){
            if (cStr[n] == 'n') {
              z++;
              mod.location = 0;
            } else if (cStr[n] == '['){
              z++;
              sMass.clear();
              aa = cStr[n - 1];
              bMass = true;
            } else if (cStr[n] == ']'){
              z++;
              mod.monoisotopicMassDelta = atoi(&sMass[0]);
              switch (aa){
              case 'n': mod.monoisotopicMassDelta -= 1; break;
              case 'A': mod.monoisotopicMassDelta -= 71; break;
              case 'C': mod.monoisotopicMassDelta -= 103; break;
              case 'G': mod.monoisotopicMassDelta -= 57; break;
              case 'K': mod.monoisotopicMassDelta -= 128; break;
              case 'M': mod.monoisotopicMassDelta -= 131; break;
              case 'P': mod.monoisotopicMassDelta -= 97; break;
              case 'S': mod.monoisotopicMassDelta -= 87; break;
              case 'T': mod.monoisotopicMassDelta -= 101; break;
              case 'V': mod.monoisotopicMassDelta -= 99; break;
              default: break;
              }
              if (mod.location == -1) mod.location = n - z + 1;
              pep.modification->push_back(mod);
              mod.location = -1;
              bMass = false;
            } else {
              if (bMass) {
                sMass += cStr[n];
                z++;
              }
            }
          }

          //find peptide sequence from list in mzid
          peptideEvidence_ref = m.sequenceCollection.getPeptideEvidenceFromPeptideAndProtein(pep, dbs.id);
          if (peptideEvidence_ref.size()<1){
            cout << "Warning, no peptide evidence found for: " << pep.peptideSequence.text << "/" << cStr << " from " << p[i][j].proteinName << endl;
            exit(1);
          }
          ph = pdh->addPeptideHypothesis(peptideEvidence_ref);

          m.dataCollection.analysisData.getSpectrumIdentificationItems(peptideEvidence_ref, p[i][j][k].charge, vSII);
          for (n = 0; n < vSII.size(); n++){
            //strstrstr=vSII.at(n);
            ph->addSpectrumIdentificationItemRef(vSII.at(n));
          }

        }

      }
    }
    
  }

  return true;
}

bool summary(char* in){
  CMzIdentML m;
  CPSM psm;
  size_t i;
  int j;

  cout << "Reading: " << in << endl;

  if(!m.readFile(in)) return false;

  cout << in << endl;
  cout << "Analyzed with: " << endl;
  for (i = 0; i < m.analysisSoftwareList.analysisSoftware->size(); i++){
    cout << " " << m.analysisSoftwareList.analysisSoftware->at(i).name << " version: " << m.analysisSoftwareList.analysisSoftware->at(i).version << endl;
  }
  cout << "Search Databases: " << endl;
  for (i = 0; i < m.dataCollection.inputs.searchDatabase->size(); i++){
    cout << " " << m.dataCollection.inputs.searchDatabase->at(i).location << endl;
  }
  cout << "Total Unique Proteins in DB: " << m.sequenceCollection.dbSequence->size() << endl;
  cout << "Total Protein Groups:        " << m.dataCollection.analysisData.proteinDetectionList.proteinAmbiguityGroup->size() << endl;
  cout << "Total Unique Peptides:       " << m.sequenceCollection.peptide->size() << endl;
  cout << "Total PSMs:                  " << m.getPSMCount() << endl;

  cout << "First PSM that maps to at least 20 proteins: " << endl;
  for (i = 0; i < m.getPSMCount(); i++){
    psm = m.getPSM((int)i);
    if (psm.proteinCount<20) continue;
    cout << " " << psm.scanInfo.scanID
      << " " << psm.scanInfo.rTimeSec
      << " " << psm.sequenceMod
      << " " << psm.getScore(0).value << endl;
    for (j = 0; j < psm.proteinCount; j++){
      cout << "  " << psm.getProtein(j) << endl;
    }
    break;
  }
  cout << i << " psms were explored to reach this point." << endl;

  cout << "Exporting hopethisworks.mzid" << endl;
  m.writeFile("hopethisworks.mzid");

  return true;
}
