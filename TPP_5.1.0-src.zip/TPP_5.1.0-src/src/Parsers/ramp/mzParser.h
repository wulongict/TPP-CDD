/* fake mzParser.h for those wishing to use RAMP+ProteoWizard */
#include "ramp.h"
