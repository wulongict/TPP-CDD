#ifndef CONSTANTS_H
#define CONSTANTS_H


#ifndef Boolean
typedef unsigned int Boolean;
#endif






#endif
