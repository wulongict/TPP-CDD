#include "CAnalysisParams.h"

CAnalysisParams::CAnalysisParams(){
  cvParam=new vector<sCvParam>;
  userParam=new vector<sUserParam>;

  sCvParam cv;
  sUserParam u;

  cvParam->push_back(cv);
  userParam->push_back(u);
}
CAnalysisParams::CAnalysisParams(const CAnalysisParams& c){
  size_t i;
  cvParam = new vector<sCvParam>;
  userParam = new vector<sUserParam>;
  for (i = 0; i<c.cvParam->size(); i++) cvParam->push_back(c.cvParam->at(i));
  for (i = 0; i<c.userParam->size(); i++) userParam->push_back(c.userParam->at(i));
}

CAnalysisParams::~CAnalysisParams(){
  delete cvParam;
  delete userParam;
}

//operators
CAnalysisParams& CAnalysisParams::operator=(const CAnalysisParams& c){
  if (this != &c){
    size_t i;
    delete cvParam;
    delete userParam;
    cvParam = new vector<sCvParam>;
    userParam = new vector<sUserParam>;
    for (i = 0; i<c.cvParam->size(); i++) cvParam->push_back(c.cvParam->at(i));
    for (i = 0; i<c.userParam->size(); i++) userParam->push_back(c.userParam->at(i));
  }
  return *this;
}

void CAnalysisParams::writeOut(FILE* f, int tabs){
  int i;
  size_t j;

  for (i = 0; i<tabs; i++) fprintf(f, " ");
  fprintf(f, "<AnalysisParams>\n");

  if (tabs > -1){
    for (j = 0; j<cvParam->size(); j++) cvParam->at(j).writeOut(f, tabs + 1);
    for (j = 0; j<userParam->size(); j++) userParam->at(j).writeOut(f, tabs + 1);
  } else {
    for (j = 0; j<cvParam->size(); j++) cvParam->at(j).writeOut(f);
    for (j = 0; j<userParam->size(); j++) userParam->at(j).writeOut(f);
  }

  for (i = 0; i<tabs; i++) fprintf(f, " ");
  fprintf(f, "</AnalysisParams>\n");

}
