#include "CPepXMLAnalysis.h"

CPepXMLAnalysis::CPepXMLAnalysis(){
  analysis.clear();
  version.clear();
}

void CPepXMLAnalysis::clear(){
  analysis.clear();
  version.clear();
}
