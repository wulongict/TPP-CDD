/*
Copyright 2017, Michael R. Hoopmann, Institute for Systems Biology
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#ifndef _CSPECTRUMIDENTIFICATIONITEM_H
#define _CSPECTRUMIDENTIFICATIONITEM_H

#include "CFragmentation.h"
#include "mzIMLStructs.h"
#include <string>
#include <vector>

using namespace std;

class CSpectrumIdentificationItem {
public:

  //Constructors & Destructor
  CSpectrumIdentificationItem();
  CSpectrumIdentificationItem(const CSpectrumIdentificationItem& s);
  ~CSpectrumIdentificationItem();

  //Data members
  double calculatedMassToCharge;
  float calculatedPI;
  int chargeState;
  double experimentalMassToCharge;
  string id;
  string massTableRef;
  string name;
  bool passThreshold;
  string peptideRef;
  int rank;
  string sampleRef;
  vector<sPeptideEvidenceRef>* peptideEvidenceRef;
  CFragmentation fragmentation;
  vector<sCvParam>* cvParam;
  vector<sUserParam>* userParam;

  //operators
  CSpectrumIdentificationItem& operator=(const CSpectrumIdentificationItem& s);

  //Functions
  void addPeptideEvidenceRef(sPeptideEvidenceRef& s);
  void addPSMValue(string alg, string scoreID, int value);
  void addPSMValue(string alg, string scoreID, double value);
  void addPSMValue(string alg, string scoreID, string value);
  void writeOut(FILE* f, int tabs = -1);

private:
};

#endif
