/*
Copyright 2017, Michael R. Hoopmann, Institute for Systems Biology
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#ifndef _CPXPROTEIN_H
#define _CPXPROTEIN_H

#include "cpxPeptide.h"
#include <string>
#include <vector>

using namespace std;

class cpxProtein{
public:

  //Constructors & Destructors
  cpxProtein();
  cpxProtein(const cpxProtein& c);
  ~cpxProtein();

  //Operators
  cpxPeptide& operator[](const size_t index);
  cpxProtein& operator=(const cpxProtein& c);
  //bool operator==(const CProteinAmbiguityGroup& c);

  //Data members
  double confidence;
  string groupSiblingID;
  int nIndistinguishableProteins;
  double pctSpectrumIDs;
  double percentCoverage;
  double probability;
  string proteinName;
  int totalNumberDistinctPeptides;
  int totalNumberPeptides;
  vector<string>* uniqueStrippedPeptides;
  vector<cpxPeptide>* peptide;

  //Functions
  size_t size();
  //void writeOut(FILE* f, int tabs = -1);

private:
};

#endif