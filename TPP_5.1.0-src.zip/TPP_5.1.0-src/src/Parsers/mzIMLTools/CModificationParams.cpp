/*
Copyright 2017, Michael R. Hoopmann, Institute for Systems Biology
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include "CModificationParams.h"

CModificationParams::CModificationParams(){
  CSearchModification sm;
  searchModification = new vector<CSearchModification>;
  searchModification->push_back(sm);
}

CModificationParams::CModificationParams(const CModificationParams& c){
  searchModification = new vector<CSearchModification>;
  for (size_t i = 0; i<c.searchModification->size(); i++) searchModification->push_back(c.searchModification->at(i));
}

CModificationParams::~CModificationParams(){
  delete searchModification;
}

CModificationParams& CModificationParams::operator=(const CModificationParams& c){
  if (this != &c){
    delete searchModification;
    searchModification = new vector<CSearchModification>;
    for (size_t i = 0; i<c.searchModification->size(); i++) searchModification->push_back(c.searchModification->at(i));
  }
  return *this;
}

bool CModificationParams::operator==(const CModificationParams& c){
  if (this==&c) return true;
  if (searchModification->size() != c.searchModification->size()) return false;
  size_t i,j;
  for (i = 0; i < searchModification->size(); i++){
    for (j = 0; j < c.searchModification->size(); j++) {
      if (searchModification->at(i) == c.searchModification->at(j)) break;
    }
    if (j == c.searchModification->size()) return false;
  }
  return true;
}

bool CModificationParams::operator!=(const CModificationParams& c){
  return !operator==(c);
}

void CModificationParams::addSearchModification(bool fixed, double mass, string residues, bool protTerm){

  //clear any placeholders
  if (searchModification->at(0).residues.compare("null") == 0) searchModification->clear();

  CSearchModification sm;
  sm.fixedMod=fixed;
  sm.massDelta=mass;
  if (protTerm) {
    sm.residues.clear();
  } else {
    if (residues[0] == 'n' || residues[0] == 'c') sm.residues = ".";
    else sm.residues=residues;
  }

  //add cvParams from lookup table
  sm.cvParam->at(0) = findCvParam(mass, residues);

  //add specificity rules
  if (protTerm){
    if (residues.size()>0 && residues[0] == 'n'){
      sm.specificityRules.cvParam->at(0).accession = "MS:1002057";
      sm.specificityRules.cvParam->at(0).cvRef = "PSI-MS";
      sm.specificityRules.cvParam->at(0).name = "modification specificity protein N-term";
    }
    if (residues.size()>0 && residues[0] == 'c'){
      sm.specificityRules.cvParam->at(0).accession = "MS:1002058";
      sm.specificityRules.cvParam->at(0).cvRef = "PSI-MS";
      sm.specificityRules.cvParam->at(0).name = "modification specificity protein C-term";
    }
  }
  if (residues.size()>0 && residues[0] == 'n'){
    sm.specificityRules.cvParam->at(0).accession = "MS:1001189";
    sm.specificityRules.cvParam->at(0).cvRef = "PSI-MS";
    sm.specificityRules.cvParam->at(0).name = "modification specificity peptide N-term";
  }
  if (residues.size()>0 && residues[0] == 'c'){
    sm.specificityRules.cvParam->at(0).accession = "MS:1001190";
    sm.specificityRules.cvParam->at(0).cvRef = "PSI-MS";
    sm.specificityRules.cvParam->at(0).name = "modification specificity peptide C-term";
  }

  searchModification->push_back(sm);

}

void CModificationParams::addSearchModification(CSearchModification& c){

  //clear any placeholders
  if (searchModification->at(0).residues.compare("null") == 0) searchModification->clear();
  searchModification->push_back(c);

}

sCvParam CModificationParams::findCvParam(double mass, string residues){
  sCvParam cv;
  cv.accession = "MS:1001460";
  cv.name = "unknown modification";
  cv.cvRef = "PSI-MS";
  if (fabs(mass - 15.994915) < 0.001){
    cv.accession = "UNIMOD:35"; cv.cvRef = "UNIMOD"; cv.name = "Oxidation";
  } else if (fabs(mass - 57.021464) < 0.001){
    if (residues.size()>0 && residues[0] == 'C') {
      cv.accession = "UNIMOD:4"; cv.cvRef = "UNIMOD"; cv.name = "Carbamidomethylation";
    } 
  } else if (fabs(mass - 144.102063) < 0.001){
    cv.accession = "UNIMOD:214"; cv.cvRef = "UNIMOD"; cv.name = "iTRAQ4plex";
  }
  return cv;
}

sCvParam CModificationParams::getModificationCvParam(double monoisotopicMassDelta, string& residues, bool nTerm, bool cTerm){
  size_t i;
  for (i = 0; i < searchModification->size(); i++){
    if ((nTerm || cTerm) && fabs(searchModification->at(i).massDelta - monoisotopicMassDelta)<0.001 && searchModification->at(i).residues.compare(".") == 0){
      return searchModification->at(i).cvParam->at(0);
    } else if (fabs(searchModification->at(i).massDelta - monoisotopicMassDelta)<0.001 && searchModification->at(i).residues.compare(residues)==0) {
      return searchModification->at(i).cvParam->at(0);
    } 
  }
  sCvParam cv;
  cv.accession = "MS:1001460";
  cv.name = "unknown modification";
  cv.cvRef = "PSI-MS";
  return cv;
}

void CModificationParams::writeOut(FILE* f, int tabs){

  if (searchModification->at(0).cvParam->at(0).accession.compare("null") == 0) return;

  int i;
  for (i = 0; i<tabs; i++) fprintf(f, " ");
  fprintf(f, "<ModificationParams>\n");

  size_t j;
  if (tabs>-1) {
    for (j = 0; j<searchModification->size(); j++) searchModification->at(j).writeOut(f, tabs + 1);
  } else {
    for (j = 0; j<searchModification->size(); j++) searchModification->at(j).writeOut(f, tabs);
  }

  for (i = 0; i<tabs; i++) fprintf(f, " ");
  fprintf(f, "</ModificationParams>\n");

}
