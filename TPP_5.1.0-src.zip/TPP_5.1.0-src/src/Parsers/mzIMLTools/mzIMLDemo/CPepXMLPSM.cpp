/*
Copyright 2017, Michael R. Hoopmann, Institute for Systems Biology
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include "CPepXMLPSM.h"  

CPepXMLPSM::CPepXMLPSM(){
  xlIndex=0;
  xlType=0;
  rank=0;
  calcPSMNeutMass=0;
  probability=0;
  iProphetProbability=0;
  peptide=NULL;
  xlPeptide=NULL;
  psmScores = new vector<PepXMLPepScore>;
}

CPepXMLPSM::CPepXMLPSM(const CPepXMLPSM& p){
  xlIndex=p.xlIndex;
  xlType=p.xlType;
  rank=p.rank;
  calcPSMNeutMass=p.calcPSMNeutMass;
  probability=p.probability;
  iProphetProbability=p.iProphetProbability;
  peptide=NULL;
  if(p.peptide!=NULL) peptide = new CPepXMLPeptide(*p.peptide);
  xlPeptide=NULL;
  if(p.xlPeptide!=NULL) xlPeptide= new CPepXMLPeptide(*p.xlPeptide);
  size_t i;
  psmScores = new vector<PepXMLPepScore>;
  for(i=0;i<p.psmScores->size();i++) psmScores->push_back(p.psmScores->at(i));  
}

CPepXMLPSM::~CPepXMLPSM(){
  delete psmScores;
  if(peptide!=NULL) delete peptide;
  if(xlPeptide!=NULL) delete xlPeptide;
}

CPepXMLPSM& CPepXMLPSM::operator=(const CPepXMLPSM& p){
  if(this!=&p){
    if(peptide!=NULL) delete peptide;
    if(xlPeptide!=NULL) delete xlPeptide;
    delete psmScores;

    xlIndex=p.xlIndex;
    xlType=p.xlType;
    rank=p.rank;
    calcPSMNeutMass=p.calcPSMNeutMass;
    probability=p.probability;
    iProphetProbability=p.iProphetProbability;
    peptide=NULL;
    xlPeptide=NULL;
    if(p.peptide!=NULL) peptide = new CPepXMLPeptide(*p.peptide);
    if(p.xlPeptide!=NULL) xlPeptide= new CPepXMLPeptide(*p.xlPeptide);

    size_t i; 
    psmScores = new vector<PepXMLPepScore>;
    for(i=0;i<p.psmScores->size();i++) psmScores->push_back(p.psmScores->at(i));  
  }
  return *this;
}

void CPepXMLPSM::clear(){
  xlIndex=0;
  xlType=0;
  rank=0;
  calcPSMNeutMass=0;
  probability=0;
  iProphetProbability=0;
  if(peptide!=NULL) delete peptide;
  if(xlPeptide!=NULL) delete xlPeptide;
  peptide=NULL;
  xlPeptide=NULL;
  delete psmScores;
  psmScores = new vector<PepXMLPepScore>;
}
