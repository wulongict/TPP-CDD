// Tandem2xml.cxx
//     Main entry point for converting X!Tandem output to
//     pepXML.

#include <iostream>

using namespace std;

#include "Tandem2xml.h"
#include "TandemResultsParser.h"
#include "Parsers/Algorithm2XML/masscalc.h"
#include "Common/constants.h"

#include "Common/TPPVersion.h" // contains version number, name, revision

int main(int argc, char* argv[]) {
  hooks_tpp handler(argc,argv); // set up install paths etc

  if (argc < 2 || argc > 3) {
    cerr << " " << argv[0] << "(" << szTPPVersionInfo << ")" << endl;
    cerr << "Usage: " << argv[0] << " <input-file> [<output-file>]\n";
    exit(EXIT_FAILURE);
  }

  TandemResultsParser results;
  results.setFileName(argv[1]);
  if (argc == 3)
    results.setOutputFile(argv[2]);
  
  if (!results.writePepXML())
    exit(EXIT_FAILURE);

  return 0;
}

// Output helpers
string indentChars("   ");
string indentNL("\n");
string& nl()
{return indentNL; }
string& nlIn()
{
  indentNL.append(indentChars);
  return indentNL;
}
string& nlOut()
{
  int lenCur = (int) indentNL.size();
  int lenIndent = (int) indentChars.size();
  if (lenCur > lenIndent)
    indentNL.erase(lenCur - lenIndent);
  return indentNL;
}
